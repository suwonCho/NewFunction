﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Function;
using Function.Db;

namespace AutoUpdateClient
{
	public partial class frmUpdateClient : Form
	{
		/// <summary>
		/// 오라클 연결 스트링
		/// </summary>
		OracleDB.strConnect strConn;

		AutoUpdateSvr.AutoUpdateServer web;

		Function.Util.Log clsLog = new Function.Util.Log(@".\UpdateClient\", "UpdateClient", 30, true);

		readonly string strXmlPath = @"./UpdateClient.xml";
		string strBackgroundImgae_Path = @".\update.jpg";
		string strLogoImgae_Path = @".\logo.bmp";
		string strICON_Path = @".\icon.ico";
		Function.Util.XML xml;

		public const string key = "D0cS3iiX9GFj+9OKvKQtV+FulVkBE/o8";
		public const string IV = "zKSFCHfbnpY=";

		/// <summary>
		/// 서버 타입 : ORACLE, WEB
		/// </summary>
		string strSvrType = string.Empty;

		/// <summary>
		/// 업데이트 후 타겟폴더에서 실행할 파일 
		/// </summary>
		string strSTARTUPFILE;
		/// <summary>
		/// 업데이트 타입..
		/// </summary>
		string strUpdateType;
		/// <summary>
		/// 대상 폴더(업데이트한 파일을 이동할 폴더)
		/// </summary>
		string strTargetPath;
		/// <summary>
		/// 업데이트 파일 저장 폴더..
		/// </summary>
		string strPathUpdateTemp;

		char chrEmpty = Convert.ToChar(15);
		clsDBFunc.delFileInfo_GetFile evtReceiveFile;

		Thread thStartUp;

		public frmUpdateClient()
		{
			InitializeComponent();
			try
			{
				xml = new Function.Util.XML(Function.Util.XML.enXmlType.File, strXmlPath);

				try
				{
					strBackgroundImgae_Path = xml.GetSingleNodeValue("BackgroundImgae_Path");
					strLogoImgae_Path = xml.GetSingleNodeValue("LogoImgae_Path");
					strICON_Path = xml.GetSingleNodeValue("ICON_Path");
				}
				catch
				{
				}

				if (Function.system.clsFile.FileExists(strICON_Path))
				{
					this.Icon = new Icon(strICON_Path);
				}

				if (Function.system.clsFile.FileExists(strBackgroundImgae_Path))
				{
					Image img = new Bitmap(strBackgroundImgae_Path, false);
					this.BackgroundImage = img;
				}


				if (Function.system.clsFile.FileExists(strLogoImgae_Path))
				{
					picLogo.Load(strLogoImgae_Path);
					picLogo.SizeMode = PictureBoxSizeMode.StretchImage;
				}
				else
				{
					picLogo.Visible = false;
				}


				strPathUpdateTemp = @"Temp\";
				Function.system.clsFile.FolderCreate(strPathUpdateTemp);

				evtReceiveFile = new clsDBFunc.delFileInfo_GetFile(FileDownloading);

				this.Opacity = 0;
				Function.form.control.Invoke_Control_Text(lblVersion, "V." + Application.ProductVersion);
				clsLog.WLog("업데이트 프로그램을 실행합니다.\tv" + Application.ProductVersion);
			}
			catch (Exception ex)
			{
				clsLog.WLog_Exception("frmUpdateClient", ex);
			}

			

		}


		private void StartUp()
		{
			try
			{

				for (int i = 1; i < 11; i++)
				{
					double dbl = i * 0.1;

					Function.form.control.Invoke_Form_Opacity(this, dbl);

					Thread.Sleep(150);
					Application.DoEvents();
				}
								
				DoEvent(true, "Config파일 읽는 중..");



				
				//업데이트 타입을 저장
				strUpdateType = xml.GetSingleNodeValue("UPDATETYPE");
				//대상폴더 지정
				strTargetPath = xml.GetSingleNodeValue("TARGETFOLDER");

				if (strTargetPath != string.Empty) strTargetPath += @"\";

				strSTARTUPFILE = xml.GetSingleNodeValue("STARTUPFILE");

				strSvrType = xml.GetSingleNodeValue("SERVER/SERVERTYPE");
				
				xml.chSingleNode("SERVER/" + strSvrType);

				Function.Util.cryptography CR = new Function.Util.cryptography();
				CR.Key = key;
				CR.IV = IV;


				switch(strSvrType)
				{
					case "ORACLE":
						strConn.strTNS = xml.GetSingleNodeValue("TNS");
						strConn.strID = xml.GetSingleNodeValue("ID"); //CR.Decrypting(xml.GetSingleNodeValue("ID"));
						strConn.strPass = xml.GetSingleNodeValue("PASS"); //CR.Decrypting(xml.GetSingleNodeValue("PASS"));
						
						break;

					case "WEB":
						web = new AutoUpdateSvr.AutoUpdateServer();
						web.Url = xml.GetSingleNodeValue("URL");
						break;

					default:
						throw new Exception("Server Type을 알 수 없습니다.");
				}

				DoEvent(true, "임시폴더 파일을 삭제합니다.");
				//temp폴더에 있는 파일을 삭제한다.
				Function.system.clsFile.FolderFileDelete(strPathUpdateTemp);

				//파일을 다운로드 받는다.
				FileDownload();

				DoEvent(true, "업데이트 파일을 이동합니다.");
				//temp폴데에 있는 파일을 이동시킨다. -> 파일무버에서 처리 한다.
				//Function.system.clsFile.FolderFileMove(strPathUpdateTemp, strTargetPath);

			}
			catch(Exception ex)
			{
				clsLog.WLog_Exception("StartUp", ex);
			}
			finally
			{
				DoEvent(true, "업데이트가 완료되었습니다.");
				clsLog.WLog("업데이트 프로그램을 종료합니다.");

				try
				{

					strPathUpdateTemp = strPathUpdateTemp.Replace(" ", chrEmpty.ToString());
					strTargetPath = strTargetPath.Replace(" ", chrEmpty.ToString());
					strSTARTUPFILE = strSTARTUPFILE.Replace(" ", chrEmpty.ToString());

					strSTARTUPFILE = Function.Fnc.StringAdd(strTargetPath, strSTARTUPFILE, "\\");
					if (strTargetPath.Trim().Equals(string.Empty)) strTargetPath = chrEmpty.ToString();


					System.Diagnostics.Process pro = new System.Diagnostics.Process();
					pro.StartInfo.FileName = "FileMover.exe";
					//pro.StartInfo.Arguments = string.Format(@"""{0}"" """"{1}"" """"{2}""", strPathUpdate, strPath , strSTARTUPFILE);
					pro.StartInfo.Arguments = string.Format(@"{0} {1} {2}", strPathUpdateTemp, strTargetPath, strSTARTUPFILE);
					pro.Start();
				}
				catch(Exception ex)
				{ 	}

				Function.form.control.Invoke_Form_Close(this);
			}
		}


		private void DoEvent(bool isTotal, string strMsg)
		{
			if(isTotal)
				Function.form.control.Invoke_Control_Text(lblTotalInfo, strMsg);
			else
				Function.form.control.Invoke_Control_Text(lblSubInfo, strMsg);


			Application.DoEvents();
			Thread.Sleep(50);
		}


		private void FileDownload()
		{
			try
			{
				DoEvent(true, "서버에서 업데이트 내역을 확인합니다");

				using (DataSet ds = clsSvr.File_GetList(strSvrType, strUpdateType, strConn, web)) 
				{
					int intUpdateTotalCount = ds.Tables[0].Rows.Count;
					int intUpdateCount = 0;

					DoEvent(true, string.Format("업데이트 항목확인 {0}건 - 파일 다운로드 시작", intUpdateTotalCount));
					
					
					foreach (DataRow dr in ds.Tables[0].Rows)
					{
						intUpdateCount++;
						Function.form.control.Invoke_Control_Text(lblSubCount, string.Format("{0:D2}/{1:D2}", intUpdateCount, intUpdateTotalCount));
						Function.form.control.Invoke_Control_Text(lblTotal, string.Format("{0:D0}%", 100 * intUpdateCount / intUpdateTotalCount  ));
						Function.form.control.Invoke_ProgressBar_Value(pBarTotal, intUpdateTotalCount, intUpdateCount);

						string strFileName = strTargetPath + Fnc.obj2String(dr["FileName"]);
						string strTempFileName = strPathUpdateTemp + Fnc.obj2String(dr["FileName"]);
						string strVersion = Fnc.obj2String(dr["Version"]);
						DateTime dtFileDate = (DateTime)dr["FileDate"];
						string strCrc = Fnc.obj2String(dr["CRC"]);
						int intFileSize = Convert.ToInt32(dr["FileSize"]);
						bool isUpdate = false;

						string strFileVersion = string.Empty;
						DateTime dtFileFileDate = DateTime.Now;

						isUpdate = false;

						DoEvent(false, string.Format("파일[{0}]을 확인 합니다.",dr["FileName"]));

						if (Function.system.clsFile.FileExists(strFileName))
						{
							System.IO.FileInfo fi = new System.IO.FileInfo(strFileName);

							strFileVersion = Fnc.obj2String(Function.system.clsFile.FileGetVersion(fi.FullName));
							dtFileFileDate = fi.LastWriteTime;

							if (strFileVersion != strVersion || Fnc.obj2String(dtFileFileDate) != Fnc.obj2String(dtFileDate))
							{
								isUpdate = true;
								clsLog.WLog(string.Format("파일[{0}]을 업데이트 합니다. - VERSION[{1}] FILEDATE[{2}] -> VERSION[{3}] FILEDATE[{4}]",
									dr["FileName"], strVersion, dtFileDate, strFileVersion, dtFileFileDate));
							}

						}
						else
						{
							isUpdate = true;

							clsLog.WLog(string.Format("파일[{0}]을 다운로드 받습니다. - VERSION[{1}] FILEDATE[{2}]",
									dr["FileName"], strVersion, dtFileDate));
						}


						if(!isUpdate)
						{
							clsLog.WLog(string.Format("파일[{0}]은 업데이트 필요 없음- VERSION[{1}] FILEDATE[{2}]", 
									dr["FileName"], strVersion, dtFileDate));
						}

						int intErrCnt = 0;
						string strFileCrc = string.Empty;

                        while (isUpdate)
						{
							strFileCrc = clsSvr.FileInfo_GetFile(strSvrType, strUpdateType, Fnc.obj2String(dr["FileName"]).ToUpper(),
									strPathUpdateTemp, intFileSize, evtReceiveFile, strConn, web);

							GC.Collect();
							Application.DoEvents();
							GC.WaitForPendingFinalizers();

							//crc검사
							if (strCrc != strFileCrc)
							{
								intErrCnt++;

								Function.system.clsFile.FileDelete(strPathUpdateTemp + Fnc.obj2String(dr["FileName"]));

								//3회까지 시도한다.
								if (intErrCnt > 2)
									isUpdate = false;
								else
								{
									isUpdate = true;
								}
							}
							else
							{
								isUpdate = false;
								System.IO.FileInfo fi = new System.IO.FileInfo(strTempFileName);
								fi.LastWriteTime = dtFileDate;
								
							}

						}



					}
				}

				DoEvent(true, "서버에서 파일 다운로드가 완료 되었습니다.");

			}
			catch
			{
				//ProcExecption(ex);
				throw;
			}
			finally
			{
				//this.Close();
			}
		}

		private void FileDownloading(string strFileName, int intTotalSize, int intRecevedFileSize)
		{
			Function.form.control.Invoke_Control_Text(lblSubInfo, string.Format("{0} {1}/{2}kb", strFileName, intRecevedFileSize, intTotalSize));
			Function.form.control.Invoke_ProgressBar_Value(pBarSub, intTotalSize ,intRecevedFileSize);
			Function.form.control.Invoke_Control_Text(lblSub, string.Format("{0:D0}%", 100 * intRecevedFileSize/intTotalSize));

		}

		private void ProcExecption(Exception ex)
		{
			Fnc.ShowMsg(ex.Message, string.Empty, frmMessage.enMessageType.OK);
		}


		private void frmUpdateClient_Load(object sender, EventArgs e)
		{

			thStartUp = new Thread(new ThreadStart(StartUp));
			thStartUp.IsBackground = true;
			thStartUp.Start();
		}
	}
}