﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Function;
using Function.form;
using Function.Util;

namespace AutoUpdater
{
	public partial class frmSetting : Function.form.frmBaseForm
	{
		/// <summary>
		/// 새로운 로우 여부
		/// </summary>
		bool isNewRow = false;

		/// <summary>
		/// 새로운 로추 추가됨
		/// </summary>
		bool isNewRowAdded = false;

		DataSet dsSetting;

		DataRow _currDr = null;

		public frmSetting()
		{
			InitializeComponent();
		}

		private void DataSet_Save()
		{			
			dsSetting.WriteXml(frmUploader.strDSFileName, XmlWriteMode.WriteSchema);
		}
		
		private void InputBox_Collapes()
		{

			//if (txtUpdateType.Enabled) return;

			if (cmbType.Text.Equals(string.Empty)) return;


			enSeverType type = (enSeverType)Fnc.String2Enum(new enSeverType(), cmbType.Text);

			string strGroupName = string.Empty;

			switch (type)
			{
				case enSeverType.ORACLE:
					pnlOracle.Visible = true;
					pnlConnSql.Visible = false;
					pnlConnWEB.Visible = false;
					break;

				//case enType.SQL:
				//    strGroupName = grpConnSql.Name;
				//    break;

				case enSeverType.WEB:
					pnlOracle.Visible = false;
					pnlConnSql.Visible = false;
					pnlConnWEB.Visible = true;
					break;			
	
				default:
					pnlOracle.Visible = false;
					pnlConnSql.Visible = false;
					pnlConnWEB.Visible = false;
					break;			
			}


			string strUpdateType = txtUpdateType.Text;

			DataTable dt = dsSetting.Tables[type.ToString()];

			if (dt.Select(string.Format("UPDATETYPE = '{0}'", strUpdateType)).Length < 1)
			{
				DataRow dr = dt.NewRow();

				dr["UPDATETYPE"] = strUpdateType;
				dt.Rows.Add(dr);
				dt.AcceptChanges();
			}

			dt.DefaultView.RowFilter = string.Format("UPDATETYPE = '{0}'", strUpdateType);


		}

		
		private void btnSave_Click(object sender, EventArgs e)
		{

			//신규의 경우 UPDATETYPE 중복 체크
			if (isNewRow && dsSetting.Tables["Setting"].Select(string.Format("UPDATETYPE = '{0}'", txtUpdateType.Text)).Length > 0)
			{
				Function.clsFunction.ShowMsg(this, "중복 UpdateType", "UpdateType이 중복 되었습니다.", frmMessage.enMessageType.OK);
				return;
			}

			DataRow dr = gvSettingList.GetFocusedDataRow();

			dr["Type"] = cmbType.Text;
			dr["생성일"] = DateTime.Now;

			dsSetting.Tables["Setting"].AcceptChanges();

			DataTable dt;
			string oldUType = Fnc.obj2String(_currDr["UpdateType"]);
			string newUtype	= Fnc.obj2String(dr["UpdateType"]);

			bool isUpdateTypeCh = !oldUType.Equals(string.Empty) & !oldUType.Equals(newUtype);
			

			//세부 설정 테이블 update
			foreach (string i in Fnc.EnumItems2Strings(new enSeverType()))
			{
				dt = dsSetting.Tables[i];

				//updatetype이 변경 되면 세부 테이브로 변경 하여 준다.
				if (isUpdateTypeCh)
				{
					foreach(DataRow r in dt.Select(string.Format("UPDATETYPE = '{0}'", oldUType)))
					{
						r["UpdateType"] = newUtype;
					}
				}

				dt.AcceptChanges();
			}


			DataSet_Save();


			gvSettingList_FocusedRowChanged(null, null);
			
		}

		private void frmSetting_Load(object sender, EventArgs e)
		{

			Function.Component.DevExp.fnc.GridView_ViewInit(gvSettingList, false, false);

			foreach(string i in Fnc.EnumItems2Strings(new enSeverType()))
			{
				cmbType.ComboBoxItems.Add(i);
			}
			

			dsSetting = frmUploader.dsSetting;

			DataTable dt = dsSetting.Tables["Setting"];

			gcSettingList.DataSource = dt;
						
			//input box binding		
			
			cmbType.DataBindings.Add(new Binding("SelectedItem", dt, "Type"));
			txtUpdateType.DataBindings.Add(new Binding("Text", dt, "UPDATETYPE"));
			txtBigo.DataBindings.Add(new Binding("Text", dt, "BIGO"));
			

			dt = dsSetting.Tables["ORACLE"];
			txtOraTNS.DataBindings.Add(new Binding("Text", dt, "TNS"));
			txtOraID.DataBindings.Add(new Binding("Text", dt, "ID"));
			txtOraPass.DataBindings.Add(new Binding("Text", dt, "PASS"));
			
			dt = dsSetting.Tables["SQL"];
			txtSqlIP.DataBindings.Add(new Binding("Text", dt, "IP"));
			txtSqlDB.DataBindings.Add(new Binding("Text", dt, "DataBase"));
			txtSqlID.DataBindings.Add(new Binding("Text", dt, "ID"));
			txtSqlPass.DataBindings.Add(new Binding("Text", dt, "PASS"));

			dt = dsSetting.Tables["WEB"];
			txtWEBUrl.DataBindings.Add(new Binding("Text", dt, "URL"));
			txtWEBPass.DataBindings.Add(new Binding("Text", dt, "PASS"));


			cmdAdd.Image = (Image)Function.resIcon16.add;
			cmdDelete.Image = (Image)Function.resIcon16.delete;

			InputBox_Collapes();
			
			
		}


		/// <summary>
		/// 항목 추가
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void cmdAdd_Click(object sender, EventArgs e)
		{
			DataRow dr = dsSetting.Tables["Setting"].NewRow();
			
			dsSetting.Tables["Setting"].Rows.Add(dr);

			isNewRowAdded = true;

			Application.DoEvents();

			gvSettingList.FocusedRowHandle = gvSettingList.RowCount - 1;

			//cmbType.ComboBoxSelectIndex= -1;
			
			txtUpdateType.Enabled = true;

			

		}

		/// <summary>
		/// 항목삭제..
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void cmdDelete_Click(object sender, EventArgs e)
		{
			DataRow dr = gvSettingList.GetFocusedDataRow();


			if (dr == null)
			{				
				return;
			}


			if (Function.clsFunction.ShowMsg(this, "항목 삭제", "선택된 항목을 삭제 하시겠습니까?", frmMessage.enMessageType.YesNo) != DialogResult.Yes)
			{
				return;
			}

			string strUpdateType = Fnc.obj2String(dr["UpdateType"]);

			DataTable dt;

			//세부 설정 테이블 update
			foreach (string i in Fnc.EnumItems2Strings(new enSeverType()))
			{
				dt = dsSetting.Tables[i];


				foreach (DataRow r in dt.Select(string.Format("UPDATETYPE = '{0}'", strUpdateType)))
				{
					dt.Rows.Remove(r);
				}
				

				dt.AcceptChanges();
			}


			foreach (DataRow r in dsSetting.Tables["Setting"].Select(string.Format("UPDATETYPE = '{0}'", strUpdateType)))
			{
				dsSetting.Tables["Setting"].Rows.Remove(r);
			}

			


			dsSetting.AcceptChanges();
			DataSet_Save();

		}

		private void btnOraSave_Click(object sender, EventArgs e)
		{
			dsSetting.Tables["ORACLE"].AcceptChanges();
			DataSet_Save();
		}


		private void frmSetting_FormClosed(object sender, FormClosedEventArgs e)
		{
			frmUploader.mdiMain.UpdateItemMenu_ReMake();
		}

		/// <summary>
		/// 로우 선택이 변경
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void gvSettingList_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
		{
			//저장하시 않는 내요은 날린다
			if (isNewRowAdded)
				isNewRowAdded = false;
			else
				dsSetting.RejectChanges();

			//새로운 로우 여부 확인
			DataRow dr = gvSettingList.GetFocusedDataRow();

			_currDr = dsSetting.Tables["Setting"].NewRow();

			_currDr.ItemArray = dr.ItemArray;

			isNewRow = Fnc.obj2String(dr["UpdateType"]).Equals(string.Empty);


			InputBox_Collapes();
		}

		private void cmbType_Text_Changed(object sender, usrEventArgs e)
		{
			InputBox_Collapes();
		}

		


	
	}
}