﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AutoUpdater
{
	public partial class frmUploader : Function.form.frmBaseForm
	{

		public static DataSet dsSetting;
		public static readonly string strDSFileName = @".\Setting.xml";
		public static frmUploader mdiMain;

		public frmUploader()
		{
			InitializeComponent();
			SavePosition_Setting = Properties.Settings.Default;

			this.Text += string.Format(" v.{0}", Application.ProductVersion);
		}

		private void frmUploader_Load(object sender, EventArgs e)
		{
			//config.xml 파일을 읽는다..
			dsSetting = new DataSet();

			mdiMain = this;

			if (Function.system.clsFile.FileExists(strDSFileName))
			{
				dsSetting.ReadXml(strDSFileName);
				foreach (DataTable dt in dsSetting.Tables)
				{
					dt.PrimaryKey = new DataColumn[] { dt.Columns["UPLOADTYPE"] };
				}

				dsSetting.AcceptChanges();
			}
			else
			{
				dsSetting = new DataSet();

				DataTable dt = new DataTable("Setting");

				dt.Columns.Add(new DataColumn("TYPE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("UPDATETYPE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("BIGO", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("생성일", Type.GetType("System.DateTime")));
				dt.PrimaryKey = new DataColumn[] { dt.Columns["UPLOADTYPE"] };
				dsSetting.Tables.Add(dt);

				dt = new DataTable("ORACLE");
				dt.Columns.Add(new DataColumn("UPDATETYPE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("TNS", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("ID", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("PASS", Type.GetType("System.String")));
				dt.PrimaryKey = new DataColumn[] { dt.Columns["UPLOADTYPE"] };
				dsSetting.Tables.Add(dt);

				dt = new DataTable("SQL");
				dt.Columns.Add(new DataColumn("UPDATETYPE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("IP", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("DATABASE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("ID", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("PASS", Type.GetType("System.String")));
				dt.PrimaryKey = new DataColumn[] { dt.Columns["UPLOADTYPE"] };
				dsSetting.Tables.Add(dt);

				dt = new DataTable("TCP");
				dt.Columns.Add(new DataColumn("UPDATETYPE", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("IP", Type.GetType("System.String")));
				dt.Columns.Add(new DataColumn("PORT", Type.GetType("System.Int32")));
				dt.PrimaryKey = new DataColumn[] { dt.Columns["UPLOADTYPE"] };
				dsSetting.Tables.Add(dt);
			}

			UpdateItemMenu_ReMake();
		}


		public void UpdateItemMenu_ReMake()
		{
			updatesToolStripMenuItem.DropDownItems.Clear();

			foreach (DataRow dr in dsSetting.Tables["Setting"].Rows)
			{
				ToolStripMenuItem tsm = new ToolStripMenuItem();
				tsm.Text = Function.Fnc.obj2String(dr["BIGO"]);
				tsm.Name = Function.Fnc.obj2String(dr["UPDATETYPE"]);
				tsm.Click += new EventHandler(tsm_Click);

				updatesToolStripMenuItem.DropDownItems.Add(tsm);
			}
		}

		private void tsm_Click(object sender, EventArgs e)
		{
			ToolStripMenuItem tsm = sender as ToolStripMenuItem;

			frmUploadWindow frm = new frmUploadWindow(tsm.Name, tsm.Text);

			Function.form.control.Invoke_Form_Add_MdiChild(this, frm, true);

		}

		private void fileToolStripMenuItem_Click(object sender, EventArgs e)
		{
			frmSetting frm = new frmSetting();
			Function.form.control.Invoke_Form_Add_MdiChild(this, frm, true);
		}



	
	}
}