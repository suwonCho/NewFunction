﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

using System.Windows.Forms;
namespace prjFileMover
{	
	//파일을 이동시킨다.
	class Program
	{
		static void Main(string[] args)
		{
			string strStartFile = string.Empty;
			char chrEmpty = Convert.ToChar(15);

			//args = new string[] { @"temp", chrEmpty.ToString(), @"AUTOUPDATER.EXE" };

			//string r1 = Console.ReadLine();

			try
			{
				Thread.Sleep(500);

				string strSoruceFolder = args[0];
				string strTargetFolder = args[1];
				strStartFile = args[2];

				strSoruceFolder = strSoruceFolder.Replace(chrEmpty.ToString(), " ").Trim();
				strTargetFolder = strTargetFolder.Replace(chrEmpty.ToString(), " ").Trim();
				strStartFile = strStartFile.Replace(chrEmpty.ToString(), " ").Trim();



				//원본폴더 확인
				if (!Directory.Exists(strSoruceFolder)) return;

				//대상폴더 확인
				if (Directory.Exists(strTargetFolder))
				{
					Directory.CreateDirectory(strTargetFolder);
				}

				FolderFileMove(strSoruceFolder, strTargetFolder);
				

			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.ToString());
				string r = Console.ReadLine();
			}
			finally
			{
				if (File.Exists(strStartFile))
				{
					try
					{
						System.Diagnostics.Process pro = new System.Diagnostics.Process();
						pro.StartInfo.FileName = strStartFile;
						pro.Start();
					}
					catch (Exception ex)
					{
						MessageBox.Show(ex.ToString());
					}

				}
				
				
			}
		}


		public static void FolderFileMove(string strSourcePath, string strTargetPath)
		{
			if (!FolderExists(strSourcePath)) return;

			//FolderCreate(strTargetPath);

			FileInfo fi;

			foreach (string strFile in Directory.GetFiles(strSourcePath))
			{
				fi = new FileInfo(strFile);

				string strNewFileName =	strTargetPath + (strTargetPath.Equals(string.Empty) ? string.Empty : "\\") + fi.Name;

				if (File.Exists(strNewFileName)) File.Delete(strNewFileName);

				fi.MoveTo(strNewFileName);
			}

			foreach (string strDic in Directory.GetDirectories(strSourcePath))
			{
				DirectoryInfo di = new DirectoryInfo(strDic);
				FolderFileMove(strDic, StringAdd(strTargetPath, di.Name, "\\"));
			}

		}




		/// <summary>
		/// 폴더 존재 유무를 검사한다.
		/// </summary>
		/// <param name="strPath"></param>
		public static bool FolderExists(string strPath)
		{
			return Directory.Exists(strPath);
		}

		/// <summary>
		/// 폴더를 생성 한다.
		/// </summary>
		/// <param name="strPath"></param>
		public static void FolderCreate(string strPath)
		{
			if (!FolderExists(strPath))
			{
				Directory.CreateDirectory(strPath);
			}
		}

		/// <summary>
		/// 폴더에 있는 파일들을 삭제한다.
		/// </summary>
		/// <param name="strPath"></param>
		public static void FolderFileDelete(string strPath)
		{
			if (!FolderExists(strPath)) return;

			foreach (string strFile in Directory.GetFiles(strPath))
			{
				File.Delete(strFile);
			}

			foreach (string dir in Directory.GetDirectories(strPath))
			{
				FolderFileDelete(dir);
				Directory.Delete(dir);
			}

		}

		public static string StringAdd(string strData, string strAddData, string strSpreator)
		{
			if (strData == string.Empty)
				strData = strAddData;
			else
				strData += strSpreator + strAddData;

			return strData;
		}



	}
}
